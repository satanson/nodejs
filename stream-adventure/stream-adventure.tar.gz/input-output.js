process.stdin.pipe(process.stdout);

var spawn = require('child_process').spawn;

ls  = spawn('ls',['-lh','/usr']);
ls.stdout.on('data',function(data){
    console.log(data.toString());
});
